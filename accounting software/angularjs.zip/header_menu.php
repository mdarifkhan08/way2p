                               <ul class="nav navbar-nav">
                                <li class="dropdown">
                                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">Inventory<span class="caret"></span></a>
	                               <ul class="dropdown-menu">
		                               <li><a href="i297uxyz.php">Create Inventory</a></li>
		                               <li><a href="v2abcx23yz.php">View Inventory</a></li>
	                               </ul>
                               </li> 

                                <li class="dropdown">
                                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">Accounts<span class="caret"></span></a>
	                               <ul class="dropdown-menu">
		                               <li><a href="lmnuvst19.php">Create Account</a></li>
		                               <li><a href="jklmnabc.php">View Account</a></li>
		                               <li><a href="i1lmnuxyz.php">Input Account</a></li>
	                               </ul>
                               </li>


                               <li class="dropdown">
                                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">Abstracts<span class="caret"></span></a>
	                               <ul class="dropdown-menu">
		                               <li><a href="a123123lxcv.php">ALL</a></li>
		                               <li><a href="sale_abstract.php">Sale</a></li>
		                               <li><a href="purchase_abstract.php">Purchase</a></li>
		                               <li><a href="payment_abstract.php">Payment</a></li>
		                               <li><a href="receipt_abstract.php">Receipt</a></li>
	                               </ul>
                               </li>

                               <li class="dropdown">
                                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">Expenses<span class="caret"></span></a>
	                               <ul class="dropdown-menu">
		                               <li><a href="create_expenses_account.php">Create Expenses Account</a></li>
		                               <li><a href="view_expenses_account.php">View Expenses Account</a></li>
		                               <li><a href="expenses_input.php">Expenses Input</a></li>
		                               <li><a href="view_expenses_input.php">View Expenses Input</a></li>
	                               </ul>
                               </li>


                               <li class="dropdown">
                                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">Liabilities<span class="caret"></span></a>
	                               <ul class="dropdown-menu">
		                               <li><a href="create_liabilities_account.php">Create Liabilities Account</a></li>
		                               <li><a href="view_liabilities_account.php">View Liabilities Account</a></li>
		                               <li><a href="liabilities_input.php">Liabilities Input</a></li>
		                               <li><a href="view_liabilities_input.php">View Liabilities Input</a></li>
	                               </ul>
                               </li>



                               <li class="dropdown">
                                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">Assets<span class="caret"></span></a>
	                               <ul class="dropdown-menu">
		                               <li><a href="create_assets_account.php">Create Assets Account</a></li>
		                               <li><a href="view_assets_account.php">View Assets Account</a></li>
		                               <li><a href="assets_input.php">Assets Input</a></li>
		                               <li><a href="view_assets_input.php">View Assets Input</a></li>
	                               </ul>
                               </li>


								<!-- <li class="active"><a href="">Create Account</a></li> -->
								<!-- <li class="active"><a href="i297uxyz.php">Create Inventory</a></li> -->
								<!-- <li class="active"><a href="">View Account</a></li> -->
							<!-- 	<li class="active"><a href="">View Inventory</a></li> -->
								
								<!-- <li class="active"><a href="">Input</a></li> -->
								<!-- <li class="active"><a href="a123123lxcv.php">Abstract</a></li> -->
								<li class="active"><a href="v1tps234tuv.php">Voucher</a></li>
								<!-- <li class="active"><a href="sale_abstract.php">Sale </a></li>
								<li class="active"><a href="purchase_abstract.php">Purchase </a></li><br/> -->
								<!-- <hr/> -->
								<!-- <li class="active"><a href="create_expenses_account.php">Create Expenses Account</a></li>
								<li class="active"><a href="view_expenses_account.php">View Expenses Account</a></li>
								<li class="active"><a href="expenses_input.php">Expenses Input</a></li>
								<li class="active"><a href="view_expenses_input.php">View Expenses Input</a></li> -->
								<li class="active"><a href="trading_account.php">Trading Account</a></li>
								
								<!-- <br/>
								<hr/>
								<li class="active"><a href="create_liabilities_account.php">Create Liabilities Account</a></li>
								<li class="active"><a href="view_liabilities_account.php">View Liabilities Account</a></li>
								<li class="active"><a href="liabilities_input.php">Liabilities Input</a></li>
								<li class="active"><a href="view_liabilities_input.php">View Liabilities Input </a></li>
								<li class="active"><a href="">Trading Account</a></li>
								<br/>
								<hr/>
								<li class="active"><a href="create_assets_account.php">Create Assets Account</a></li>
								<li class="active"><a href="view_assets_account.php">View Assets Accounts</a></li>
								<li class="active"><a href="assets_input.php">Assets Input</a></li>
								<li class="active"><a href="view_assets_input.php">View Assets Input </a></li>
								<li class="active"><a href="">Trading Account</a></li>-->
								<li class="active"><a href="admin-logout.php?logout=true" class="">Logout</a></li> 
</ul>